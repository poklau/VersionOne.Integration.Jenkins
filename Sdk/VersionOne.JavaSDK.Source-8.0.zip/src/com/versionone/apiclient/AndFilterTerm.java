package com.versionone.apiclient;

/**
 * Combine terms on a filter using 'and'
 * @author jerry
 *
 */
public class AndFilterTerm extends GroupFilterTerm {

	/**
	 * Create filter without a collection of terms
	 */
	public AndFilterTerm() {
		super(new IFilterTerm[0]);
	}

	/**
	 * Create filter with a collection of terms
	 * @param terms
	 */
	public AndFilterTerm(IFilterTerm[] terms) {
		super(terms);
	}

	/**
	 * Create filter with only two terms
	 *
	 * @param term1 - first term
	 * @param term2 - second term
	 */
	public AndFilterTerm(IFilterTerm term1, IFilterTerm term2) {
		super(term1, term2);
	}

	@Override
	String getTokenSeperator() {
		return ";";
	}

}
