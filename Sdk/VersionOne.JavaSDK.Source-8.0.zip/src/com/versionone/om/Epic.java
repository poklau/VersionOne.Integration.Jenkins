/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om;

import java.util.Collection;

import com.versionone.om.filters.EpicFilter;
import com.versionone.om.filters.StoryFilter;
import com.versionone.om.listvalue.StoryType;
import com.versionone.om.listvalue.WorkitemPriority;
import com.versionone.om.listvalue.WorkitemRisk;
import com.versionone.om.listvalue.WorkitemSource;
import com.versionone.om.listvalue.WorkitemStatus;

/**
 * Represents an Epic in the VersionOne system.
 */
@MetaDataAttribute(value = "Story", assetState = 208)
public class Epic extends ProjectAsset {

    /**
     * Constructor used to represent an Epic entity that DOES exist in the
     * VersionOne System.
     *
     * @param id Unique ID of this entity.
     * @param instance this entity belongs to.
     */
    Epic(AssetID id, V1Instance instance) {
        super(id, instance);
    }

    /**
     * Constructor used to represent an Epic entity that does NOT yet exist in
     * the VersionOne System.
     *
     * @param instance this entity belongs to.
     */
    Epic(V1Instance instance) {
        super(instance);
    }

    /**
     * @return The Parent Epic that this Epic belongs to.
     */
    @MetaRenamedAttribute("Super")
    public Epic getParent() {
        return getRelation(Epic.class, "Super");
    }

    /**
     * @param value The Parent Epic that this Epic belongs to.
     */
    @MetaRenamedAttribute("Super")
    public void setParent(Epic value) {
        setRelation("Super", value);
    }

    /**
     * @return The Theme this Epic is assigned to.
     */
    @MetaRenamedAttribute("Parent")
    public Theme getTheme() {
        return getRelation(Theme.class, "Parent");
    }

    /**
     * @param value The Theme this Epic is assigned to.
     */
    @MetaRenamedAttribute("Parent")
    public void setTheme(Theme value) {
        setRelation("Parent", value);
    }

    /**
     * @return Member assigned as a customer for this Epic.
     */
    public Member getCustomer() {
        return getRelation(Member.class, "Customer");
    }

    /**
     * @param value Member assigned as a customer for this Epic.
     */
    public void setCustomer(Member value) {
        setRelation("Customer", value);
    }

    /**
     * @return This Epic's Status.
     */
    public IListValueProperty getStatus() {
        return getListValue(WorkitemStatus.class, "Status");
    }

    /**
     * @return This Epic's Priority.
     */
    public IListValueProperty getPriority() {
        return getListValue(WorkitemPriority.class, "Priority");
    }

    /**
     * @return This Epic's Source.
     */
    public IListValueProperty getSource() {
        return getListValue(WorkitemSource.class, "Source");
    }

    /**
     * @return This Epic's Risk.
     */
    public IListValueProperty getRisk() {
        return getListValue(WorkitemRisk.class, "Risk");
    }

    /**
     * @return This Epic's Type.
     */
    @MetaRenamedAttribute("Category")
    public IListValueProperty getType() {
        return getListValue(StoryType.class, "Category");
    }

    /**
     * Epics that are immediate children of this Epic.
     *
     * @param filter Limit the epic returned (If null, then all items returned).
     * @return A collection epics that belong to this epic filtered by the
     *         passed in filter.
     */
    public Collection<Epic> getChildEpics(EpicFilter filter) {
        filter = (filter != null) ? filter : new EpicFilter();
        filter.parent.clear();
        filter.parent.add(this);
        return getInstance().get().epics(filter);
    }

    /**
     * Stories that are immediate children of this Epic.
     *
     * @param filter Limit the story returned (If null, then all items
     *                returned).
     * @return A collection stories that belong to this epic filtered by the
     *         passed in filter.
     */
    public Collection<Story> getChildStories(StoryFilter filter) {
        filter = (filter != null) ? filter : new StoryFilter();
        filter.epic.clear();
        filter.epic.add(this);
        return getInstance().get().story(filter);
    }

    /**
     * @return Members that own this Epic.
     */
    public Collection<Member> getOwners() {
        return getMultiRelation("Owners");
    }

    /**
     * @return Goals this Epic is assigned to.
     */
    public Collection<Goal> getGoals() {
        return getMultiRelation("Goals");
    }

    /**
     * @return Requests associated with this Epic.
     */
    public Collection<Request> getRequests() {
        return getMultiRelation("Requests");
    }

    /**
     * @return Issues associated with this Epic.
     */
    public Collection<Issue> getIssues() {
        return getMultiRelation("Issues");
    }

    /**
     * @return High-level estimate (in story points) of this Epic.
     */
    public Double getEstimate() {
        return (Double) get("Estimate");
    }

    /**
     * @param value High-level estimate (in story points) of this Epic.
     */
    public void setEstimate(Double value) {
        set("Estimate", value);
    }

    /**
     * @return Cross-reference of this Epic with an external system.
     */
    public String getReference() {
        return (String) get("Reference");
    }

    /**
     * @param value Cross-reference of this Epic with an external system.
     */
    public void setReference(String value) {
        set("Reference", value);
    }

    /**
     * @return Name of person or organization requesting this Epic.
     */
    public String getRequestedBy() {
        return (String) get("RequestedBy");
    }

    /**
     * @param value Name of person or organization requesting this Epic.
     */
    public void setRequestedBy(String value) {
        set("RequestedBy", value);
    }

    /**
     * Inactivates the Story.
     *
     * @throws UnsupportedOperationException The Epic is an invalid state for
     *                 the Operation, e.g. it is already closed.
     * @see com.versionone.om.BaseAsset#closeImpl().
     * @see com.versionone.om.BaseAsset#closeImpl().
     */
    @Override
    void closeImpl() throws UnsupportedOperationException {
        getInstance().executeOperation(this, "Inactivate");
    }

    /**
     * Reactivates the Story.
     *
     * @throws UnsupportedOperationException The Epic is an invalid state for
     *                 the Operation, e.g. it is already active.
     * @see com.versionone.om.BaseAsset#reactivateImpl().
     */
    @Override
    void reactivateImpl() throws UnsupportedOperationException {
        getInstance().executeOperation(this, "Reactivate");
    }

    /**
     * @return True if a Story can be generated from this Epic.
     */
    public boolean canGenerateChildStory() {
        return getInstance().canExecuteOperation(this, "GenerateSubStory");
    }

    /**
     * Generates a Story that is the child of this Epic.
     *
     * @return Story that is a child of this Epic.
     * @throws UnsupportedOperationException If the Epic is not able to Generate
     *                 a child Story.
     */
    public Story generateChildStory() throws UnsupportedOperationException {
        save();
        return getInstance().executeOperation(Story.class, this,
                "GenerateSubStory");
    }

    /**
     * @return True if an Epic can be generated from this Epic.
     */
    public boolean canGenerateChildEpic() {
        return canGenerateChildStory();
    }

    /**
     * @return Generates an Epic that is the child of this Epic.
     * @throws UnsupportedOperationException If the Epic is not able to Generate
     *                 a child Epic.
     */
    public Epic generateChildEpic() throws UnsupportedOperationException {
        return generateChildStory().convertToEpic();
    }

    @Override
    boolean isActiveImpl() {
        return Byte.valueOf(get("SubState").toString()) == 64;
    }

    @Override
    boolean isClosedImpl() {
        return Byte.valueOf(get("SubState").toString()) == 128;
    }
}
