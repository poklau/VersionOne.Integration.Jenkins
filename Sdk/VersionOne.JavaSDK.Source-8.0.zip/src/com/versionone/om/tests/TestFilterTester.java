package com.versionone.om.tests;

import java.util.Collection;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.om.Story;
import com.versionone.om.filters.TestFilter;

public class TestFilterTester extends BaseSDKTester {

    @Test
    public void testType() {
        Story story = getSandboxProject().createStory("Type Filter");
        com.versionone.om.Test test = story.createTest("Type Filter");
        String taskType = test.getType().getAllValues()[0];
        test.getType().setCurrentValue(taskType);
        test.save();

        com.versionone.om.Test not = story.createTest("Doesn't match");

        resetInstance();

        TestFilter filter = new TestFilter();
        filter.type.add(taskType);

        Collection<com.versionone.om.Test> results = getSandboxProject().getTests(filter);

        Assert.assertTrue("Expected to find task that matched filter.", findRelated(test, results));
        Assert.assertFalse("Expected to NOT find task that doesn't match filter.", findRelated(not, results));
        for (com.versionone.om.Test result : results) {
            Assert.assertEquals(taskType, result.getType().getCurrentValue());
        }
    }

    @Test
    public void testStatus() {
        Story story = getSandboxProject().createStory("Status Filter");
        com.versionone.om.Test task = story.createTest("Status Filter");
        String taskStatus = task.getStatus().getAllValues()[0];
        task.getStatus().setCurrentValue(taskStatus);
        task.save();

        com.versionone.om.Test not = story.createTest("Doesn't match");

        resetInstance();

        TestFilter filter = new TestFilter();
        filter.status.add(taskStatus);

        Collection<com.versionone.om.Test> results = getSandboxProject()
                .getTests(filter);

        Assert.assertTrue("Expected to find task that matched filter.", findRelated(task, results));
        Assert.assertFalse("Expected to NOT find task that doesn't match filter.", findRelated(not, results));
        for (com.versionone.om.Test result : results) {
            Assert.assertEquals(taskStatus, result.getStatus()
                    .getCurrentValue());
        }
    }
}
