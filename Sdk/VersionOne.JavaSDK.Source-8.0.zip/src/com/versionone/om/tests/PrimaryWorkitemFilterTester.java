/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import com.versionone.om.Epic;
import com.versionone.om.PrimaryWorkitem;
import com.versionone.om.Project;
import com.versionone.om.SecondaryWorkitem;
import com.versionone.om.Story;
import com.versionone.om.Task;
import com.versionone.om.Theme;
import com.versionone.om.Workitem;
import com.versionone.om.filters.BaseAssetFilter.State;
import com.versionone.om.filters.PrimaryWorkitemFilter;
import com.versionone.om.filters.SecondaryWorkitemFilter;
import com.versionone.om.filters.StoryFilter;
import com.versionone.om.filters.TaskFilter;
import com.versionone.om.filters.WorkitemFilter;

import org.junit.Assert;
import org.junit.Test;

import java.util.Collection;

public class PrimaryWorkitemFilterTester extends PrimaryWorkitemFilterTesterBase {

    private PrimaryWorkitemFilter GetFilter() {
        PrimaryWorkitemFilter filter = new PrimaryWorkitemFilter();
        filter.project.add(sandboxProject);
        return filter;
    }

    @Test
    public void testProject() {
        int actual = getInstance().get().primaryWorkitems(GetFilter()).size();
        Assert.assertEquals(6, actual);
    }

    @Test
    public void testNoOwner() {
        PrimaryWorkitemFilter filter = GetFilter();
        filter.owners.add(null);

        int actual = getInstance().get().primaryWorkitems(filter).size();
        Assert.assertEquals(2, actual);
    }

    @Test
    public void testNoOrAndreOwner() {
        PrimaryWorkitemFilter filter = GetFilter();
        filter.owners.add(null);
        filter.owners.add(andre);

        int actual = getInstance().get().primaryWorkitems(filter).size();
        Assert.assertEquals(5, actual);
    }

    @Test
    public void testNames() {
        PrimaryWorkitemFilter filter = GetFilter();
        filter.name.add("Defect 2");
        filter.name.add("Story 2");

        int actual = getInstance().get().primaryWorkitems(filter).size();
        Assert.assertEquals(2, actual);
    }

    @Test
    public void testEstimate() {
        PrimaryWorkitemFilter filter = GetFilter();
        filter.estimate.add(1.0);
        int actual = getInstance().get().primaryWorkitems(filter).size();
        Assert.assertEquals(1, actual);
    }

    @Test
    public void testAffectedBy() {
        PrimaryWorkitemFilter filter = GetFilter();
        filter.affectedByDefects.add(defect1);
        int actual = getInstance().get().primaryWorkitems(filter).size();
        Assert.assertEquals(1, actual);
    }

    @Test
    public void testExcludeThemesEpicsAndTemplates() {

        Project root = getSandboxProject().getParentProject();

        WorkitemFilter wiFilter = new WorkitemFilter();
        wiFilter.getState().add(State.Active);

        double totalEstimate = 0.;
        for (Workitem workitem : getInstance().get().workitems(wiFilter)) {
            if (workitem.getDetailEstimate() != null) {
                totalEstimate += workitem.getDetailEstimate();
            }
        }

        final Double actual = root.getTotalDetailEstimate(wiFilter, true);
        Assert.assertEquals(totalEstimate, actual, ESTIMATES_PRECISION);
    }

    @Test
    public void testOnlyStoriesAndDefects() {
        Project root = getSandboxProject().getParentProject();

        PrimaryWorkitemFilter wiFilter = new PrimaryWorkitemFilter();
        wiFilter.getState().add(State.Active);

        double totalEstimate = 0.;
        for (Workitem workitem : getInstance().get().workitems(wiFilter)) {
            if (workitem.getDetailEstimate() != null) {
                totalEstimate += workitem.getDetailEstimate();
            }
        }

        final Double actual = root.getTotalDetailEstimate(wiFilter, true);
        Assert.assertEquals(totalEstimate, actual, ESTIMATES_PRECISION);
    }

    @Test
    public void testOnlyTasksAndTests() {
        Project root = getSandboxProject().getParentProject();

        SecondaryWorkitemFilter wiFilter = new SecondaryWorkitemFilter();
        wiFilter.getState().add(State.Active);

        double totalEstimate = 0.;
        for (Workitem workitem : getInstance().get().workitems(wiFilter)) {
            if (workitem.getDetailEstimate() != null) {
                totalEstimate += workitem.getDetailEstimate();
            }
        }

        final Double actual = root.getTotalDetailEstimate(wiFilter, true);
        Assert.assertEquals(totalEstimate, actual, ESTIMATES_PRECISION);
    }

    @Test
    public void testTaskDefaultOrder() {
        Story story = getSandboxProject().createStory("My Story");
        Task task1 = story.createTask("Task 1");
        Task task2 = story.createTask("Task 2");
        Task task3 = story.createTask("Task 3");

        task2.getRankOrder().setBelow(task3);
        task1.getRankOrder().setBelow(task2);

        // order should be 3,2,1
        Collection<SecondaryWorkitem> workitems = story
                .getSecondaryWorkitems(new TaskFilter());
        Object[] expected = new String[]{"Task 3", "Task 2", "Task 1"};
        ListAssert.areEqual(expected, workitems,
                new EntityToNameTransformer<SecondaryWorkitem>());
    }

    /**
     * Tests passing a more specific filter to a less specific query method.
     */
    @Test
    public void testTaskBuildFilter() {
        final String strTaskB = "Task B";
        final String strTaskD = "Task D";
        final String strBuildBeta = "Build Beta";

        Story story = getSandboxProject().createStory("Task Builds");
        Task taskA = story.createTask("Task A");
        Task taskB = story.createTask(strTaskB);
        Task taskC = story.createTask("Task C");
        Task taskD = story.createTask(strTaskD);

        taskA.setBuild("Build Alpha");
        taskB.setBuild(strBuildBeta);
        taskC.setBuild("Build Alpha");
        taskD.setBuild(strBuildBeta);

        taskA.save();
        taskB.save();
        taskC.save();
        taskD.save();

        TaskFilter filter = new TaskFilter();
        filter.build.add(strBuildBeta);
        Collection<SecondaryWorkitem> items = story
                .getSecondaryWorkitems(filter);
        ListAssert.areEqual(new Object[]{"Task B", "Task D"}, items,
                new EntityToNameTransformer<SecondaryWorkitem>());
    }

    @Test
    public void testNoEpicAmongPrimaryWorkitems() {
        Epic epic = getSandboxProject().createEpic("War And Piece");

        resetInstance();

        ListAssert.notcontains(epic.getName(), getInstance().get().primaryWorkitems(null), new EntityToNameTransformer<PrimaryWorkitem>());
    }

    @Test
    public void testThemes() {
        final StoryFilter sFilter = new StoryFilter();
        final Theme theme = getSandboxProject().createTheme("Test Theme");
        sFilter.theme.add(theme);

        final Collection<Story> stories = getInstance().get().story(sFilter);
        Assert.assertEquals(0, stories.size());

        story1.setTheme(theme);
        story1.save();
        resetInstance();

        final Collection<Story> storiesWithTestTheme = getInstance().get().story(sFilter);
        Assert.assertEquals(1, storiesWithTestTheme.size());
        Assert.assertEquals(story1, storiesWithTestTheme.iterator().next());
    }
}
