/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.filters;

import java.util.List;

import com.versionone.apiclient.IFilterTerm;
import com.versionone.apiclient.TokenTerm;
import com.versionone.om.Entity;
import com.versionone.om.Epic;
import com.versionone.om.Goal;
import com.versionone.om.Issue;
import com.versionone.om.Member;
import com.versionone.om.Request;
import com.versionone.om.Theme;
import com.versionone.om.listvalue.StoryType;
import com.versionone.om.listvalue.WorkitemPriority;
import com.versionone.om.listvalue.WorkitemRisk;
import com.versionone.om.listvalue.WorkitemSource;
import com.versionone.om.listvalue.WorkitemStatus;

/**
 * Filter for getting Epics.
 */
public class EpicFilter extends ProjectAssetFilter {

    @Override
	public
    Class<? extends Entity> getEntityType()
    {
        return Epic.class;
    }


    /**
     * Filter on Status.
     */
    public final List<String> status = newList();

    /**
     * Filter on Source.
     */
    public final List<String> source = newList();

    /**
     * Filter on Theme assigned.
     */
    public final List<Theme> theme = newList();

    /**
     * Filter on Customer.
     */
    public final List<Member> customer = newList();

    /**
     * Filter on Risk.
     */
    public final List<String> risk = newList();

    /**
     * Filter on Type.
     */
    public final List<String> type = newList();

    /**
     * Filter on Priority.
     */
    public final List<String> priority = newList();

    /**
     * Filter on Reference.
     */
    public final List<String> reference = newList();

    /**
     * Filter on Parent.
     */
    public final List<Epic> parent = newList();

    /**
     * Filter on Goals.
     */
    public final List<Goal> goals = newList();

    /**
     * Filter on Issues.
     */
    public final List<Issue> issues = newList();

    /**
     * Filter on Owners.
     */
    public final List<Member> owners = newList();

    /**
     * Filter on Requests.
     */
    public final List<Request> requests = newList();

    @Override
    void internalModifyFilter(FilterBuilder builder) {
        super.internalModifyFilter(builder);

        builder.simple("Reference", reference);

        builder.relation("Customer", customer);
        builder.relation("Parent", theme);
        builder.relation("Super", parent);

        builder.multiRelation("Goals", goals);
        builder.multiRelation("Issues", issues);
        builder.multiRelation("Owners", owners);
        builder.multiRelation("Requests", requests);

        builder.listRelation("Status", status, WorkitemStatus.class);
        builder.listRelation("Source", source, WorkitemSource.class);
        builder.listRelation("Risk", risk, WorkitemRisk.class);
        builder.listRelation("Category", type, StoryType.class);
        builder.listRelation("Priority", priority, WorkitemPriority.class);
    }

    @Override
    void internalModifyState(FilterBuilder builder) {

        if (hasState()) {

            if (isActive()) {
                builder.root.And(new IFilterTerm[] { new TokenTerm(
                        "AssetState='208';SubState='Active'") });
            } else {
                builder.root.And(new IFilterTerm[] { new TokenTerm(
                        "AssetState='208';SubState='Closed'") });
            }
        } else {
            builder.root.And(new IFilterTerm[] { new TokenTerm(
                    "AssetState='208'") });
        }
    }

}
