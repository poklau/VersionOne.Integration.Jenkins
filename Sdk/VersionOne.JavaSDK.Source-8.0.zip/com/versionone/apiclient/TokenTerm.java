package com.versionone.apiclient;

public class TokenTerm implements IFilterTerm {
    private String _token;

    public TokenTerm(String token) {
        _token = token;
    }

    public String getToken() {
        return _token;
    }

    public String getShortToken() {
        return _token;
    }
}
