package com.versionone.apiclient.fitnesse;

import java.util.ArrayList;
import java.util.List;

import com.versionone.apiclient.Asset;
import com.versionone.apiclient.FilterTerm;
import com.versionone.apiclient.IFilterTerm;
import com.versionone.apiclient.MetaModel;
import com.versionone.apiclient.Query;
import com.versionone.apiclient.QueryResult;
import com.versionone.apiclient.Services;
import com.versionone.apiclient.V1APIConnector;
import com.versionone.apiclient.V1Exception;

import fit.RowFixture;

public class FilterQueryFixture extends RowFixture {

	@SuppressWarnings("unchecked")
	@Override
	public Class getTargetClass() {
		return FilterQueryFixture.RowData.class;
	}

	@Override
	// args[0] - URL
	// args[1] - user Id
	// args[2] - password
	// args[3] - Asset type
	// args[4] - Where
	public Object[] query() throws Exception {
		String basicUrl = args[0];
		
		MetaModel metaModel = new MetaModel(new V1APIConnector(basicUrl + "/meta.v1/"));
		
		Services service = new Services(metaModel, new V1APIConnector(basicUrl + "/rest-1.v1/", args[1], args[2]));
		
		Query query = new Query(metaModel.getAssetType(args[3]));

		query.setFilter(parse(metaModel, args[3], args[4]));
		QueryResult queryResults = service.retrieve(query);
		Asset[] results = queryResults.getAssets();
		
		RowData[] rc = new RowData[results.length];
		
		for(int i = 0; i < results.length; ++i) {
			rc[i] = new RowData(results[i]);
		}
		
		return rc;
	}

	public class RowData {
		public String oid;
		
		RowData(Asset asset) {
			oid = asset.getOid().toString();
		}
	}	

	private IFilterTerm parse(MetaModel model, String assetType, String where) throws V1Exception {
		if(where.contains(";")) {
			return parseAnd(model, assetType, where);
		}
		else if(where.contains("|")) {
			return parseOr(model, assetType, where);
		}
		else {
			return parseOneTerm(model, assetType, where);
		}
	}

	private IFilterTerm parseAnd(MetaModel model, String assetType, String where) throws V1Exception {
		List<IFilterTerm> allTerms = new ArrayList<IFilterTerm>();
		String[] terms = where.split(";");
		for(String oneTerm : terms) {
			allTerms.add(parse(model, assetType, oneTerm));
		}
		return Query.and(allTerms.toArray(new IFilterTerm[allTerms.size()]));
	}

	private IFilterTerm parseOr(MetaModel model, String assetType, String where) throws V1Exception {
		List<IFilterTerm> allTerms = new ArrayList<IFilterTerm>();
		String[] terms = where.split("\\|");
		for(String oneTerm : terms) {
			allTerms.add(parse(model, assetType, oneTerm));
		}
		return Query.or(allTerms.toArray(new IFilterTerm[allTerms.size()]));
	}
	
	private IFilterTerm parseOneTerm(MetaModel model, String assetType, String where) throws V1Exception {
		FilterTerm oneTerm = null;
		String[] terms = null;
		if(where.contains("!=")) {
			terms = where.split("!=");
			oneTerm = Query.term(model.getAttributeDefinition(assetType + "." + terms[0]));
			oneTerm.NotEqual(terms[1].replace("'", ""));
		}
		else if(where.contains("<=")){
			terms = where.split("<=");
			oneTerm = Query.term(model.getAttributeDefinition(assetType + "." + terms[0]));
			oneTerm.LessOrEqual(terms[1].replace("'", ""));
		}
		else if(where.contains(">=")){
			terms = where.split(">=");
			oneTerm = Query.term(model.getAttributeDefinition(assetType + "." + terms[0]));
			oneTerm.GreaterOrEqual(terms[1].replace("'", ""));
		}
		else if(where.contains("<")){
			terms = where.split("<");
			oneTerm = Query.term(model.getAttributeDefinition(assetType + "." + terms[0]));
			oneTerm.Less(terms[1].replace("'", ""));
		}
		else if(where.contains(">")){
			terms = where.split(">");
			oneTerm = Query.term(model.getAttributeDefinition(assetType + "." + terms[0]));
			oneTerm.Greater(terms[1].replace("'", ""));
		}
		else{
			terms = where.split("=");
			oneTerm = Query.term(model.getAttributeDefinition(assetType + "." + terms[0]));
			oneTerm.Equal(terms[1].replace("'", ""));
		}
		
		return oneTerm;
	}
}
