package com.versionone.apiclient.tests;

import com.versionone.apiclient.CookiesManager;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class will test the CookiesManager.
 *
 * @author VersionOne
 */
public class CookiesManagerTester {

    private static final CookiesManager cookiesManager = new CookiesManager();

    private Map<String, List<String>> getHeaderData() {
        Map<String, List<String>> headers = new HashMap<String, List<String>>();
        List<String> cookies = new ArrayList<String>();
        cookies.add("name1=value1; expires=Mon, 26-May-2008 12:02:10 GMT");
        cookies.add("name2=value2; expires=Tue, 26-May-3009 12:02:10 GMT");
        headers.put("Set-Cookie", cookies);
        return headers;
    }

    @Test
    public void testCookiesExpired() {
        cookiesManager.addCookie(getHeaderData());
        final String expect = "name2=value2";
        String cookies = cookiesManager.getCookies();
        Assert.assertEquals(expect, cookies);
    }
}
