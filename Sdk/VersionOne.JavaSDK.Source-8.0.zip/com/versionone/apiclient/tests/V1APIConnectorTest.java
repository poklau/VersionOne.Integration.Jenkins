package com.versionone.apiclient.tests;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.apiclient.ConnectionException;
import com.versionone.apiclient.V1APIConnector;

/**
 * This class will test the V1APIConnector.
 * It's a duplicate of the Fitnesse integration tests
 * <p/>
 * It's not part of the nightly builds because we cannot depend on
 *
 * @author jerry
 */
public class V1APIConnectorTest {
    private static final String V1_PATH = "http://nitrogen/apiclienttest/";
//    private static final String V1_PATH = "http://integsrv01/VersionOne/";

    @Test(expected = ConnectionException.class)
    public void testInvalidUser() throws ConnectionException {
        V1APIConnector testMe = new V1APIConnector(V1_PATH, "foo", "bar");
        testMe.getData("rest-1.v1/Data/Scope/0");
    }

    @Test
    public void testValidUser() throws ConnectionException {
        V1APIConnector testMe = new V1APIConnector(V1_PATH, "admin", "admin");
        Reader results = testMe.getData("rest-1.v1/Data/Scope/0");
        Assert.assertTrue(results != null);
    }

    @Test(expected = ConnectionException.class)
    public void testURLInvalidUserAfterValid() throws ConnectionException {
        V1APIConnector testMe = new V1APIConnector(V1_PATH, "admin", "admin");
        Reader results = testMe.getData("rest-1.v1/Data/Scope/0");
        Assert.assertTrue(results != null);
        testMe = new V1APIConnector(V1_PATH, "foo", "bar");
        testMe.getData("rest-1.v1/Data/Scope/0");
    }

    private final static String paramName = "test-param";
    private final static String paramValue = "test-value";
    private final static int port = 4444;

    @Test
    public void testUserCustomHeader() throws ConnectionException, IOException {
        final TestServer test = new TestServer();
        test.start();

        //waiting till server is started
        int count = 0;
        while (test.isNotRun && count < 50) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                // Do nothing
            }
            count++;
        }
        // JIC
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // Do nothing
        }

        V1APIConnector testMe = new V1APIConnector("http://localhost:" + port, "foo", "bar");
        testMe.customHttpHeaders.put(paramName, paramValue);
        testMe.getData();
    }

    private class TestServer extends Thread {
        public volatile boolean isNotRun = true;
        final String HTTP = "HTTP/1.0 ";

        public void run() {
            ServerSocket serverSocket = null;
            Socket clientSocket = null;
            PrintWriter out = null;
            BufferedReader in = null;
            try {
                serverSocket = new ServerSocket(port);
                isNotRun = false;
                clientSocket = serverSocket.accept();

                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(
                        new InputStreamReader(
                                clientSocket.getInputStream()));
                String inputLine;
                String result = "0";
                while ((inputLine = in.readLine()) != null) {
                    if (inputLine.equals(paramName + ": " + paramValue)) {
                        result = "200 OK";
                        break;
                    } else if (inputLine.equals("")) {
                        result = "406 Not Acceptable";
                        break;
                    }
                }

                out.println(HTTP + result);
                out.println("Content-Type:text/plain");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    out.close();
                }
                try {
                    if (in != null) {
                        in.close();
                    }
                    if (clientSocket != null) {
                        clientSocket.close();
                    }
                    if (serverSocket != null) {
                        serverSocket.close();
                    }
                } catch (Exception ex) {
                    // Do nothing
                }
            }
        }
    }
}

