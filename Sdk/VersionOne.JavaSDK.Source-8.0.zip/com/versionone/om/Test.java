/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om;

import com.versionone.om.listvalue.TestStatus;
import com.versionone.om.listvalue.TestType;

/**
 * Represents a Test in the VersionOne System.
 */
@MetaDataAttribute(value = "Test", defaultOrderByToken = "Test.Order")
public class Test extends SecondaryWorkitem {

    Test(AssetID id, V1Instance instance) {
        super(id, instance);
    }

    Test(V1Instance instance) {
        super(instance);
    }

    /**
     * @return The Type of this Test.
     */
    @MetaRenamedAttribute("Category")
    public IListValueProperty getType() {
        return getListValue(TestType.class, "Category");
    }

    /**
     * @return The Status of this Test.
     */
    public IListValueProperty getStatus() {
        return getListValue(TestStatus.class, "Status");
    }

    /**
     * @return This item's order.
     */
    @MetaRenamedAttribute("Order")
    public Rank<Test> getRankOrder() {
        return (Rank<Test>) getRank("Order");
    }

    @Override
    void closeImpl() throws UnsupportedOperationException {
        getInstance().executeOperation(this, "Inactivate");
    }

    @Override
    void reactivateImpl() throws UnsupportedOperationException {
        getInstance().executeOperation(this, "Reactivate");
    }
}