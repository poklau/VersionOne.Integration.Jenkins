/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om;

import com.versionone.Duration;
import com.versionone.DB.DateTime;
import com.versionone.apiclient.MimeType;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Create Assets.
 */
public class V1InstanceCreator {
    private final V1Instance instance;

    V1InstanceCreator(V1Instance instance) {
        this.instance = instance;
    }

    /**
     * Create a new project entity with a name, parent project, begin date, and
     * optional schedule.
     *
     * @param name name of project.
     * @param parentProject parent project for created project.
     * @param beginDate start date of created project.
     * @param schedule Schedule that defines how this project's iterations are
     *                spaced.
     * @return A newly minted Project that exists in the VersionOne system.
     */
    public Project project(String name, Project parentProject,
            DateTime beginDate, Schedule schedule) {
        Project project = new Project(instance);
        project.setName(name);
        project.setParentProject(parentProject);
        project.setBeginDate(beginDate);
        project.setSchedule(schedule);
        project.save();
        return project;
    }

    /**
     * Create a new project entity with a name, parent project, begin date, and
     * optional schedule.
     *
     * @param name name of project.
     * @param parentProjectID id of parent project for created project.
     * @param beginDate start date of created project.
     * @param schedule Schedule that defines how this project's iterations are
     *                spaced.
     * @return A newly minted Project that exists in the VersionOne system.
     */
    public Project project(String name, AssetID parentProjectID,
            DateTime beginDate, Schedule schedule) {
        return project(name, new Project(parentProjectID, instance),
                beginDate, schedule);
    }

    /**
     * Create a new member entity with a name, short name, and default role.
     *
     * @param name The full name of the user.
     * @param shortName An alias or nickname used throughout the VersionOne user
     *                interface.
     * @param defaultRole The new user's default role on projects.
     * @return A newly minted Member that exists in the VersionOne system.
     */
    public Member member(String name, String shortName, Role defaultRole) {
        Member member = new Member(instance);

        member.setName(name);
        member.setShortName(shortName);
        member.setDefaultRole(defaultRole);
        member.save();
        return member;
    }

    /**
     * Create a new member entity with a name and short name.
     *
     * @param name The full name of the user.
     * @param shortName An alias or nickname used throughout the VersionOne user
     *                interface.
     * @return A newly minted Member that exists in the VersionOne system.
     */
    public Member member(String name, String shortName) {
        return member(name, shortName, Role.TEAM_MEMBER);
    }

    /**
     * Create a new team entity with a name.
     *
     * @param name name of team.
     * @return A newly minted Team that exists in the VersionOne system.
     */
    public Team team(String name) {
        Team team = new Team(instance);

        team.setName(name);
        team.save();
        return team;
    }

    /**
     * Create a new Story with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Story will be in.
     * @return A newly minted Story that exists in the VersionOne system.
     */
    public Story story(String name, Project project) {
        Story story = new Story(instance);

        story.setName(name);
        story.setProject(project);
        story.save();
        return story;
    }

    /**
     * Create a new story with a name. Set the story's IdentifiedIn to the given
     * retrospective and the project to the retrospective's project.
     *
     * @param name The initial name of the story.
     * @param retrospective The retrospective this story was identified in.
     * @return A newly minted Story that exists in the VersionOne system.
     */
    public Story story(String name, Retrospective retrospective) {
        Story story = new Story(instance);

        story.setName(name);
        story.setIdentifiedIn(retrospective);
        story.setProject(retrospective.getProject());
        story.save();
        return story;
    }

    /**
     * Create a new Defect with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Defect will be in.
     * @return A newly minted Defect that exists in the VersionOne system.
     */
    public Defect defect(String name, Project project) {
        Defect defect = new Defect(instance);

        defect.setName(name);
        defect.setProject(project);
        defect.save();
        return defect;
    }

    /**
     * Create a new Task with a name. Assign it to the given primary workitem.
     *
     * @param name The initial name of the task.
     * @param primaryWorkitem The PrimaryWorkitem this Task will belong to.
     * @return A newly minted Task that exists in the VersionOne system.
     */
    public Task task(String name, PrimaryWorkitem primaryWorkitem) {
        Task task = new Task(instance);

        task.setName(name);
        task.setParent(primaryWorkitem);
        task.save();
        return task;
    }

    /**
     * Create a new Test with a name. Assign it to the given primary workitem.
     *
     * @param name The initial name of the test.
     * @param primaryWorkitem The PrimaryWorkitem this Test will belong to.
     * @return A newly minted Test that exists in the VersionOne system.
     */
    public Test test(String name, PrimaryWorkitem primaryWorkitem) {
        Test test = new Test(instance);

        test.setName(name);
        test.setParent(primaryWorkitem);
        test.save();
        return test;
    }

    /**
     * Create a new Theme with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Theme will be in.
     * @return A newly minted Theme that exists in the VersionOne system.
     */
    public Theme theme(String name, Project project) {
        Theme theme = new Theme(instance);

        theme.setName(name);
        theme.setProject(project);
        theme.save();
        return theme;
    }

    /**
     * Create a new Goal with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Goal will be in.
     * @return A newly minted Goal that exists in the VersionOne system.
     */
    public Goal goal(String name, Project project) {
        Goal goal = new Goal(instance);

        goal.setName(name);
        goal.setProject(project);
        goal.save();
        return goal;
    }

    /**
     * Create a new Issue with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Issue will be in.
     * @return A newly minted Issue that exists in the VersionOne system.
     */
    public Issue issue(String name, Project project) {
        Issue issue = new Issue(instance);

        issue.setName(name);
        issue.setProject(project);
        issue.save();
        return issue;
    }

    /**
     * Creates an Issue related to a Retrospective.
     *
     * @param name The name of the Issue.
     * @param retrospective The Retrospective to relate the Issue to.
     * @return The newly saved Issue.
     */
    public Issue issue(String name, Retrospective retrospective) {
        Issue issue = new Issue(instance);

        issue.setName(name);
        issue.setProject(retrospective.getProject());
        issue.save();
        issue.getRetrospectives().add(retrospective);
        return issue;
    }

    /**
     * Create a new Request with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Request will be in.
     * @return A newly minted Request that exists in the VersionOne system.
     */
    public Request request(String name, Project project) {
        Request request = new Request(instance);

        request.setName(name);
        request.setProject(project);
        request.save();
        return request;
    }

    /**
     * Create a new Epic with a name.
     *
     * @param name The initial name of the entity.
     * @param project The Project this Epic will be in.
     * @return A newly minted Epic that exists in the VersionOne system.
     */
    public Epic epic(String name, Project project) {
        Story story = new Story(instance);

        story.setName(name);
        story.setProject(project);
        story.save();

        return story.convertToEpic();
    }

    /**
     * Create a new link with a name.
     *
     * @param name The initial name of the link.
     * @param asset The asset this link belongs to.
     * @param url The URL of the link.
     * @param onMenu True to show on the asset's detail page menu.
     * @return A newly minted Link that exists in the VersionOne system.
     */
    public Link link(String name, BaseAsset asset, String url,
            boolean onMenu) {
        Link link = new Link(instance);

        link.setAsset(asset);
        link.setName(name);
        link.setURL(url);
        link.setOnMenu(onMenu);
        link.save();
        return link;
    }

    /**
     * Create a new note with a name, asset, content, and 'personal' flag.
     *
     * @param name The initial name of the note.
     * @param asset The asset this note belongs to.
     * @param content The content of the note.
     * @param personal True if this note is only visible to.
     * @return A newly minted Note that exists in the VersionOne system.
     */
    public Note note(String name, BaseAsset asset, String content,
            boolean personal) {
        Note note = new Note(instance);

        note.setAsset(asset);
        note.setName(name);
        note.setContent(content);
        note.setPersonal(personal);
        note.save();
        return note;
    }

    /**
     * Create a new TestSuite with a name.
     *
     * @param name The initial name of the TestSuite.
     * @param reference A free text field used for reference (perhaps to an
     *                external system).
     * @return A newly minted TestSuite that exists in the VersionOne system.
     */
    public TestSuite testSuite(String name, String reference) {
        TestSuite testSuite = new TestSuite(instance);

        testSuite.setName(name);
        testSuite.setReference(reference);
        testSuite.save();
        return testSuite;
    }

    /**
     * Create a new attachment with a name.
     *
     * @param name The name of the attachment.
     * @param asset The asset this attachment belongs to.
     * @param filename The name of the original attachment file.
     * @param stream The read-enabled stream that contains the attachment
     *                content to upload.
     * @return A newly minted Attachment that exists in the VersionOne system.
     * @throws AttachmentLengthExceededException if attachment is too long.
     * @throws ApplicationUnavailableException if appears any problem with
     *                 connection to service.
     */
    public Attachment attachment(String name, BaseAsset asset,
            String filename, InputStream stream)
            throws AttachmentLengthExceededException,
            ApplicationUnavailableException {
        Attachment attachment = new Attachment(instance);

        attachment.setAsset(asset);
        attachment.setName(name);
        attachment.setFilename(filename);
        attachment.setContentType(MimeType.resolve(filename));
        attachment.save();

        if (stream != null) {
            attachment.readFrom(stream);
        }

        return attachment;
    }

    /**
     * Create a new retrospective with a name.
     *
     * @param name The name of the retrospective.
     * @param project The project this retrospective belongs to.
     * @return A newly minted Retrospective that exists in the VersionOne
     *         system.
     */
    public Retrospective retrospective(String name, Project project) {
        Retrospective retro = new Retrospective(instance);

        retro.setProject(project);
        retro.setName(name);
        retro.save();
        return retro;
    }

    /**
     * Create a new iteration using suggested system values.
     *
     * @param project The project is used to determine the schedule this iteration belongs to.
     * @return A newly minted Iteration that exists in the VersionOne system.
     */

    public Iteration iteration(Project project) {
        Iteration iteration = instance.createNew(Iteration.class, project);

        iteration.save();
        //Fix bug on the backend. (C# comment)
        iteration.makeFuture();
        return iteration;
    }

    /**
     * Create a new iteration with a name, begin date, and end date.
     *
     * @param name The name of the iteration.
     * @param schedule The schedule this iteration belongs to.
     * @param beginDate The begin date or start date of this iteration.
     * @param endDate The end date of this iteration.
     * @return A newly minted Iteration that exists in the VersionOne system.
     */

    public Iteration iteration(String name, Schedule schedule,
            DateTime beginDate, DateTime endDate) {
        Iteration iteration = new Iteration(instance);

        iteration.setName(name);
        iteration.setSchedule(schedule);
        iteration.setBeginDate(beginDate);
        iteration.setEndDate(endDate);
        iteration.save();
        return iteration;
    }

    /**
     * Create a new effort record with a value and date, assigned to the given
     * workitem and member.
     *
     * @param value the value of the effort record.
     * @param item the workitem to assign the effort record to.
     * @param member the member to assign the effort record to. If is null then
     *                member not set.
     * @param date the date to log the effort record against. If is null then
     *                date not set.
     * @return A newly minted Effort Record that exists in the VersionOne
     *         system.
     * @throws IllegalStateException if Effort tracking is not enabled.
     */
    public Effort effort(double value, Workitem item, Member member,
            DateTime date) throws IllegalStateException {
        if (!instance.getConfiguration().effortTrackingEnabled) {
            throw new IllegalStateException("Effort Tracking is disabled.");
        }

        instance.preventTrackingLevelAbuse(item);

        Effort actual = instance.createNew(Effort.class, item);
        actual.setValue(value);

        if (member != null) {
            actual.setMember(member);
        }

        if (date != null) {
            actual.setDate(date);
        }
        actual.save();
        return actual;
    }

    /**
     * Create a new effort record for the currently logged in member.
     *
     * @param value The value of the effort record.
     * @param item The workitem to assign the effort record to.
     * @return A newly minted Effort Record that exists in the VersionOne
     *         system.
     * @throws IllegalStateException if Effort tracking is not enabled.
     */
    public Effort effort(double value, Workitem item)
            throws IllegalStateException {
        return effort(value, item, null, null);
    }

    /**
     * Create a new Build Project with a name and reference.
     *
     * @param name Initial name.
     * @param reference Reference value.
     * @return A newly minted Build Project that exists in the VersionOne
     *         system.
     */
    public BuildProject buildProject(String name, String reference) {
        BuildProject buildProject = new BuildProject(instance);

        buildProject.setName(name);
        buildProject.setReference(reference);
        buildProject.save();
        return buildProject;
    }

    /**
     * Create a new Build Run in the given Build Project with a name and date.
     *
     * @param buildProject The Build Project this Build Run belongs to.
     * @param name Name of the build project.
     * @param date The Date this Build Run ran.
     * @return A newly minted Build Run that exists in the VersionOne system.
     */
    public BuildRun buildRun(BuildProject buildProject, String name,
            DateTime date) {
        BuildRun buildRun = new BuildRun(instance);

        buildRun.setName(name);
        buildRun.setBuildProject(buildProject);
        buildRun.setDate(date);
        buildRun.save();
        return buildRun;
    }

    /**
     * Create a new ChangeSet with a name and reference.
     *
     * @param name Initial name.
     * @param reference Reference value.
     * @return A newly minted ChangeSet that exists in the VersionOne system.
     */
    public ChangeSet changeSet(String name, String reference) {
        ChangeSet changeSet = new ChangeSet(instance);

        changeSet.setName(name);
        changeSet.setReference(reference);
        changeSet.save();
        return changeSet;
    }
    
    /**
     * Create a new schedule entity with a name, iteration length, and iteration gap
     * @param name Name of the new schedule
     * @param iterationLength The duration an iteration will last in this schedule
     * @param iterationGap The duration between iterations in this schedule.
     * @return A newly minted Schedule that exists in the VersionOne system.
     */
    public Schedule schedule(String name, Duration iterationLength, Duration iterationGap)
    {
        Schedule schedule = new Schedule(instance);
        schedule.setName(name);
        schedule.setIterationLength(iterationLength);
        schedule.setIterationGap(iterationGap);
        schedule.save();
        return schedule;
    }

	/**
	 * Create a new response to an existing note with a name, content, and 'personal' flag
	 * 
	 * @param responseTo The Note to respond to
	 * @param name The initial name of the note
	 * @param content The content of the note
	 * @param personal True if this note is only visible to
	 * @return A newly minted Note in response to the original one that exists in the VersionOne system.
	 */
	public Note note(Note responseTo, String name, String content, boolean personal)
	{
		Note note = new Note(responseTo, instance);
		note.setName(name);
		note.setContent(content);
		note.setPersonal(personal);
		note.save();
		return note;
	}


	/**
	 * Create a new Message with a subject and recipient.
	 * 
	 * @param subject Message subject.
	 * @param messageBody Message body.
	 * @return A newly minted Message that exists in the VersionOne system.
	 */
	public Message message(String subject, String messageBody)
	{
		Collection<Member> recipients = new ArrayList<Member>();
		return message(subject, messageBody, recipients);
	}

	///<summary>
	/// Create a new Message with a subject and recipient.
	///</summary>
	///<param name="subject">Message subject.</param>
	///<param name="messageBody">Message body.</param>
	///<param name="recipient">Who this message will go to.</param>
	///<returns>A newly minted Message that exists in the VersionOne system.</returns>
	public Message message(String subject, String messageBody, Member recipient)
	{
		Collection<Member> recipients = new ArrayList<Member>();
		recipients.add(recipient);
		return message(subject, messageBody, recipients);
	}

	///<summary>
	/// Create a new Message with a subject and recipient.
	///</summary>
	///<param name="subject">Message subject.</param>
	///<param name="messageBody">Message body.</param>
	///<param name="recipients">Who this message will go to. May be null.</param>
	///<returns>A newly minted Message that exists in the VersionOne system.</returns>
	public Message message(String subject, String messageBody, Collection<Member> recipients)
	{
		Message message = new Message(instance);
		message.setName(subject);
		message.setDescription(messageBody);
		if (recipients != null)
			for(Member recipient : recipients)
			{
				message.getRecipients().add(recipient);
			}
		message.save();
		return message;
	}
}
