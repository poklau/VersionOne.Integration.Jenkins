package com.versionone.om.tests;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.apiclient.APIException;
import com.versionone.apiclient.ConnectionException;
import com.versionone.apiclient.V1APIConnector;
import com.versionone.om.ApiClientInternals;
import com.versionone.om.ApplicationUnavailableException;
import com.versionone.om.AuthenticationException;
import com.versionone.om.V1Instance;

public class ApiClientInternalsTester extends BaseSDKTester {
    private final static int port = 4444;
    private final static String paramName = "test-param";
    private final static String paramValue = "test-value";
    private final static String paramName2 = "test-param 2";
    private final static String paramValue2 = "test-value 2";

    @Test
    public void testConnectionsWithCustomsParameters() throws ConnectionException, APIException, SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {

	V1Instance connection = new V1Instance(
		"http://localhost:" + port + "/", getUsername(), getPassword());
	connection.getCustomHttpHeaders().put(paramName, paramValue);
	ApiClientInternals test = connection.getApiClient();

	Map<String, String> connections = test.getCustomHttpHeaders();

	Assert.assertEquals(1, test.getCustomHttpHeaders().size());
	Assert.assertEquals(paramValue, test.getCustomHttpHeaders().get(paramName));

	test.getV1Config();
	Assert.assertEquals(1, connections.size());
	connection.getCustomHttpHeaders().put(paramName2, paramValue2);
	Assert.assertEquals(2, connections.size());
	connection.getCustomHttpHeaders().remove(paramName2);
	Assert.assertEquals(1, connections.size());

	Class<?> classDeligatorDictionary = null;
	Class<?>[] classList= ApiClientInternals.class.getDeclaredClasses();
	for (int i=0; i<classList.length; i++) {
	    if (classList[i].getName().equals("com.versionone.om.ApiClientInternals$DeligatorDictionary")) {
		classDeligatorDictionary = classList[i];
		break;
	    }
	}
	if (classDeligatorDictionary == null) {
	    Assert.fail("Not found ApiClientInternals.DeligatorDictionary class");
	}
	Field connectorsField = classDeligatorDictionary.getDeclaredField("connectors");
	connectorsField.setAccessible(true);
	List<V1APIConnector> insideConnection = (List<V1APIConnector>)connectorsField.get(connections);

	//exist only config connection
	verifyDataExist(paramName, paramValue, insideConnection);

	//add new connection
	test.getMetaModel();
	Assert.assertEquals(2, insideConnection.size());
	verifyDataExist(paramName, paramValue, insideConnection);

	connection.getCustomHttpHeaders().put(paramName2, paramValue2);
	verifyDataExist(paramName2, paramValue2, insideConnection);

	connection.getCustomHttpHeaders().remove(paramName);
	verifyDataExist(paramName2, paramValue2, insideConnection);

	connection.getCustomHttpHeaders().remove(paramName2);
	// list of params is empty
	try {
	    verifyDataExist(paramName2, paramValue2, insideConnection);
	    Assert.fail("List must be empty");
	} catch (AssertionError e) {
	}

	// add service connection
	test.getServices();
	Assert.assertEquals(3, insideConnection.size());
	// list of params is empty
	try {
	    verifyDataExist(paramName2, paramValue2, insideConnection);
	    Assert.fail("List must be still empty");
	} catch (AssertionError e) {
	}

	// call config one more time
	test.getV1Config();
	Assert.assertEquals(3, insideConnection.size());
	connection.getCustomHttpHeaders().put(paramName2, paramValue2);
	verifyDataExist(paramName2, paramValue2, insideConnection);

	test.getCustomHttpHeaders().clear();
	Assert.assertEquals(0, test.getCustomHttpHeaders().size());
	for (V1APIConnector connect : insideConnection) {
	    Assert.assertEquals(0, connect.customHttpHeaders.size());
	}
	Assert.assertEquals(3, insideConnection.size());
    }

    private void verifyDataExist(String key, String value, List<V1APIConnector> connections) {
	for (V1APIConnector connection : connections) {
	    Assert.assertEquals(value, connection.customHttpHeaders.get(key));
	}

    }

    @Test
    public void testConnectionsValidateWithCustomsParameters() {

	runServer();

	V1Instance connection = new V1Instance(
		"http://localhost:" + port + "/", getUsername(), getPassword());
	connection.getCustomHttpHeaders().put(paramName, paramValue);
	try {
	    connection.validate();
	} catch (AuthenticationException e) {
	    // TODO: handle exception
	} catch (ApplicationUnavailableException e) {
	    Assert.fail("No custom parameters in request");
	}


    }

    private void runServer() {
	TestServer test = new TestServer();
	new Thread(test).start();

	// waiting till server is started
	int count = 0;
	while (test.isNotRun && count < 50) {
	    try {
		Thread.sleep(200);
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	    count++;
	}
	// JIC
	try {
	    Thread.sleep(1000);
	} catch (InterruptedException e) {
	    e.printStackTrace();
	}
    }

    private class TestServer implements Runnable {
	public boolean isNotRun = true;
	final String HTTP = "HTTP/1.0 ";

	public void run() {
	    ServerSocket serverSocket = null;
	    try {
		serverSocket = new ServerSocket(port);
	    } catch (IOException e) {
		System.out.println("Could not listen on port: " + port);
		System.exit(-1);
	    }
	    Socket clientSocket = null;
	    try {
		isNotRun = false;
		clientSocket = serverSocket.accept();
	    } catch (IOException e) {
		System.err.println("Accept failed.");
		System.exit(1);
	    }

	    PrintWriter out = null;
	    BufferedReader in = null;
	    try {
		out = new PrintWriter(clientSocket.getOutputStream(), true);
		in = new BufferedReader(new InputStreamReader(clientSocket
			.getInputStream()));
		String inputLine;
		String result = "0";
		while ((inputLine = in.readLine()) != null) {
		    if (inputLine.equals(paramName + ": " + paramValue)) {
			result = "200 OK";
			break;
		    } else if (inputLine.equals("")) {
			result = "406 Not Acceptable";
			break;
		    }
		}

		out.println(HTTP + result);
		out.println("Content-Type:text/plain");
		out.println("");
		out.println("<test>ok</test>");

	    } catch (Exception ex) {
		System.out.println(ex.getMessage());
	    } finally {
		if (out != null) {
		    out.close();
		}
		try {
		    if (in != null) {
			in.close();
		    }
		    if (clientSocket != null) {
			clientSocket.close();
		    }
		    if (serverSocket != null) {
			serverSocket.close();
		    }
		} catch (Exception ex) {

		}
	    }

	}

    }
}
