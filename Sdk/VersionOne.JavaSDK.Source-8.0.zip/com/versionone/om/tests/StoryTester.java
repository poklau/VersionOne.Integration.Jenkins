/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.DB.DateTime;
import com.versionone.om.AssetID;
import com.versionone.om.Member;
import com.versionone.om.PrimaryWorkitem;
import com.versionone.om.Role;
import com.versionone.om.Story;

public class StoryTester extends BaseSDKTester {

    @Test
    public void StoryOwner() {
        PrimaryWorkitem story = getSandboxProject().createStory("Add an owner to me");

        Member owner = getInstance().create().member("Dude", "dud", Role.PROJECT_LEAD);
        getSandboxProject().getAssignedMembers().add(owner);
        getSandboxProject().save();

        story.getOwners().add(owner);
        story.save();

        resetInstance();
        story = getInstance().get().storyByID(story.getID());
        owner = getInstance().get().memberByID(owner.getID());

        Assert.assertTrue(findRelated(owner, story.getOwners()));
        Assert.assertTrue(findRelated(story, owner.getOwnedPrimaryWorkitems(null)));
    }

    @Test
    public void CreateAndRetrieveStory() {
        final String name = "New Story";

        AssetID id = getInstance().create().story(name, getSandboxProject()).getID();

        resetInstance();

        Story story = getInstance().get().storyByID(id);

        Assert.assertEquals(story.getName(), name);
    }

    @Test
    public void StoryOrder() {
        Story story1 = getSandboxProject().createStory("Story 1");
        Story story2 = getSandboxProject().createStory("Story 2");

        AssetID id1 = story1.getID();
        AssetID id2 = story2.getID();

        story1.getRankOrder().setBelow(story2);

        Assert.assertTrue(story1.getRankOrder().isBelow(story2));
        Assert.assertTrue(story2.getRankOrder().isAbove(story1));

        resetInstance();

        story1 = getInstance().get().storyByID(id1);
        story2 = getInstance().get().storyByID(id2);

        story1.getRankOrder().setAbove(story2);

        Assert.assertTrue(story1.getRankOrder().isAbove(story2));
        Assert.assertTrue(story2.getRankOrder().isBelow(story1));
    }

    @Test(expected = IllegalStateException.class)
    public void Actuals() {
        Story story = getSandboxProject().createStory("Story 1");
        story.createEffort(5.); //Should throws
    }

    @Test(expected = IllegalStateException.class)
    public void ActualsWithDateAndMember() {
        final DateTime date = new DateTime("2007-01-01");

        Member member = getInstance().get().memberByID("Member:20");
        Story story = getSandboxProject().createStory("Story 2");
        story.createEffort(10., member, date);  //Should throws
    }

    @Test
    public void GetByDisplayID() {
        String defectName = "GetByDisplayIDTest";
        String displayID = getSandboxProject().createStory(defectName).getDisplayID();

        resetInstance();

        Assert.assertEquals(defectName, getInstance().get().
                storyByDisplayID(displayID).getName());
    }

    @Test(expected = IllegalStateException.class)
    public void HonorTrackingLevelDetailEstimate() {
        // The V1SDKTests system is assumed to be configured for "Story:Off"
        Story story = getSandboxProject().createStory("Honor Tracking Level");
        story.setDetailEstimate(10.); //Should throws
    }

    @Test(expected = IllegalStateException.class)
    public void HonorTrackingLevelToDo() {
        // The V1SDKTests system is assumed to be configured for "Story:Off"
        Story story = getSandboxProject().createStory("Honor Tracking Level");
        story.setToDo(10.); //Should throws
    }

    @Test(expected = IllegalStateException.class)
    public void HonorTrackingLevelEffort() {
        // The V1SDKTests system is assumed to be configured for "Defect:On"
        Story story = getSandboxProject().createStory("Honor Tracking Level");
        story.createEffort(10.); // should throws
    }

    @Test(expected = ClassCastException.class)
    public void ValidObjectWrongType() {
        Story testMe = getInstance().get().storyByID("Story:1088");
        Assert.assertNull(testMe);
    }

    @Test
    public void emptyAttributesTest() {
        final String name = "EmptyAttributesTest";
        Story story = getInstance().create().story(name, getSandboxProject());
        Assert.assertEquals(null, story.getReference());
        Assert.assertEquals(null, story.getEstimate());
        Assert.assertEquals(null, story.getDescription());

        story.setReference("ref");
        story.setEstimate(5d);
        story.setDescription("test");
        story.save();
        final AssetID id = story.getID();
        resetInstance();

        story = getInstance().get().storyByID(id);
        story.setReference(null);
        story.setEstimate(null);
        story.setDescription("");
        story.save();
        resetInstance();

        story = getInstance().get().storyByID(id);
        Assert.assertEquals(null, story.getReference());
        Assert.assertEquals(null, story.getEstimate());
        Assert.assertEquals(null, story.getDescription());

        story.delete();
    }

    /**
     * Test for defect D-01045 
     */
    @Test
    public void closeAndReactivateTest() {
        final String name = "�loseAndReactivateTest";
        Story story = getSandboxProject().createStory(name);
        Assert.assertFalse(story.canReactivate());
        Assert.assertTrue(story.canClose());
        Assert.assertFalse(story.isClosed());
        Assert.assertTrue(story.isActive());

        story.close();
        Assert.assertTrue(story.canReactivate());
        Assert.assertFalse(story.canClose());
        Assert.assertTrue(story.isClosed());
        Assert.assertFalse(story.isActive());

        story.reactivate();
        Assert.assertFalse(story.canReactivate());
        Assert.assertTrue(story.canClose());
        Assert.assertFalse(story.isClosed());
        Assert.assertTrue(story.isActive());

        story.delete();
    }
}
