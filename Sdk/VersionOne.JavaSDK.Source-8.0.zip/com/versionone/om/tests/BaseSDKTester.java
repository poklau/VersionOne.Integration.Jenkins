/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import java.rmi.dgc.VMID;
import java.util.Collection;
import java.util.Iterator;

import com.versionone.Duration;
import com.versionone.DB.DateTime;
import com.versionone.om.AssetID;
import com.versionone.om.BaseAsset;
import com.versionone.om.Defect;
import com.versionone.om.Entity;
import com.versionone.om.Iteration;
import com.versionone.om.Member;
import com.versionone.om.Project;
import com.versionone.om.Schedule;
import com.versionone.om.Story;
import com.versionone.om.Team;
import com.versionone.om.V1Instance;
import com.versionone.om.TransformIterable.ITransformer;

public abstract class BaseSDKTester {
    protected final static String SCOPE_ZERO = "Scope:0";
    protected final static double ESTIMATES_PRECISION = 0.0001;
	protected final static String TEST_URL_PROPERTY = "test.websiteurl";
    private V1Instance instance;
    private AssetID sandboxProjectID;
    private AssetID sandboxIterationID;
    private AssetID sandboxTeamID;
    private AssetID sandboxMemberID;

    protected String getApplicationPath() {
    	String url = System.getProperties().getProperty(TEST_URL_PROPERTY);
    	if(null == url){
    		url = "http://localhost/V1JavaSDKTests/";
    	}
    	else if(!url.endsWith("/"))
    		url += "/";
   		return url;
    }

    protected String getUsername() {
        return "admin";
    }

    protected String getPassword() {
        return "admin";
    }

    protected String getSandboxName() {
        return getClass().getSimpleName();
    }

    /**
     * The name to be used when creating your sandbox projects and teams.
     * Override to specify a special name. I like to call mine Fred.
     */
    protected void newSandboxProject() {
        sandboxProjectID = null;
    }

    /**
     * @return The ID of your sandbox project, so you can get it again yourself,
     *         Elvis.
     */
    protected AssetID getSandboxProjectID() {
        if (sandboxProjectID == null) {
            Project rootProject = getInstance().get().projectByID(
                    SCOPE_ZERO);
            Project sandbox = createSandboxProject(rootProject);

            sandboxProjectID = sandbox.getID();
        }
        return sandboxProjectID;
    }

    /**
     * Override to create your sandbox with properties other than the defaults
     * (today as the start date, child of Scope:0, no schedule). You go,
     * Einstein.
     *
     * @param rootProject root project
     * @return created sub project
     */
    protected Project createSandboxProject(Project rootProject) {
        return getInstance().create().project(getSandboxName(),
                rootProject, DateTime.now(), null);
    }

    /**
     * @return A sandbox for you to play in. The Entity is retrieved from the
     *         Instance on every call (so ResetInstance will force a re-query).
     *         You don't need to do anything to initialize it. Just use it,
     *         Mort.
     */
    protected Project getSandboxProject() {
        return getInstance().get().projectByID(getSandboxProjectID());
    }

    protected void newSandboxIteration() {
        sandboxIterationID = null;
    }

    /**
     * @return The ID of your sandbox iteration, so you can get it again
     *         yourself, Elvis.
     */
    protected AssetID getSandboxIterationID() {

        if (sandboxIterationID == null) {
            sandboxIterationID = getSandboxProject().createIteration().getID();
        }
        return sandboxIterationID;
    }

    /**
     * @return A sandbox for you to play in. The Entity is retrieved from the
     *         Instance on every call (so ResetInstance will force a re-query).
     *         You don't need to do anything to initialize it. Just use it,
     *         Mort.
     */
    protected Iteration getSandboxIteration() {
        return getInstance().get().iterationByID(getSandboxIterationID());
    }

    protected void newSandboxTeam() {
        sandboxTeamID = null;
    }

    /**
     * @return The ID of your sandbox team, so you can get it again yourself,
     *         Elvis.
     */
    protected AssetID getSandboxTeamID() {
        if (sandboxTeamID == null) {
            sandboxTeamID = getInstance().create()
                    .team(getSandboxName()).getID();
        }
        return sandboxTeamID;
    }

    /**
     * @return A sandbox for you to play in. The Entity is retrieved from the
     *         Instance on every call (so ResetInstance will force a re-query).
     *         You don't need to do anything to initialize it. Just use it,
     *         Mort.
     */
    protected Team getSandboxTeam() {
        return getInstance().get().teamByID(getSandboxTeamID());
    }

    protected void newSandboxMember() {
        sandboxMemberID = null;
    }

    /**
     * @return The ID of your sandbox member, so you can get it again yourself,
     *         Elvis.
     */
    protected AssetID getSandboxMemberID() {
        if (sandboxMemberID == null) {
            sandboxMemberID = getInstance().create().member(
                    getSandboxName(), getSandboxName()).getID();
        }
        return sandboxMemberID;
    }

    /**
     * @return A sandbox for you to play in. The Entity is retrieved from the
     *         Instance on every call (so ResetInstance will force a re-query).
     *         You don't need to do anything to initialize it. Just use it,
     *         Mort.
     */
    protected Member getSandboxMember() {
        return getInstance().get().memberByID(getSandboxMemberID());
    }

    protected V1Instance getInstance() {
        if (instance == null) {
            instance = new V1Instance(getApplicationPath(), getUsername(),
                    getPassword());
            instance.validate();
        }
        return instance;
    }

    protected void resetInstance() {
        instance = null;
    }

    /**
     * @return the {@code Guid} object.
     */
    public static String newGuid() {
        final VMID guid = new VMID();
        return guid.toString();
    }

    public static class EntityToNameTransformer<T extends BaseAsset>
            implements ITransformer<T, String> {
        public String  transform(T input) {
            return input.getName();
        }
    }

    protected static class EntityToAssetIDTransformer<T extends Entity>
            implements ITransformer<T, String> {
        public String transform(T input) {
            return input.getID().getToken();
        }
    }

    protected static <T> boolean findRelated(T needle, Collection<T> haystack) {
        boolean found = false;
        for (T straw : haystack) {
            if (straw.equals(needle)) {
                found = true;
                break;
            }
        }
        return found;
    }
    
    private AssetID _sandboxScheduleID;
    protected void newSandboxSchedule()
    {
        _sandboxScheduleID = null;
    }

    /// <summary>
    /// The ID of your sandbox Schedule, so you can get it again yourself, Elvis.
    /// </summary>
    protected AssetID getSandboxScheduleID()
    {
    	if (_sandboxScheduleID == null)
    	{
    		Schedule sandbox = createSandboxSchedule();
    		_sandboxScheduleID = sandbox.getID();
    	}
    	return _sandboxScheduleID;
    }

    /// <summary>
    /// Override to create your sandbox with properties other than the defaults (today as the start date, child of Scope:0, no schedule).  You go, Einstein.
    /// </summary>
    /// <returns></returns>
    protected Schedule createSandboxSchedule()
    {
        return instance.create().schedule(this.getSandboxName(), new Duration(14, Duration.Unit.Days), new Duration(0, Duration.Unit.Days) );
    }

    /// <summary>
    /// A sandbox for you to play in.  The Entity is retrieved from the Instance on every call (so ResetInstance will force a re-query).  You don't need to do anything to initialize it.  Just use it, Mort.
    /// </summary>
    protected Schedule getSandboxSchedule()
    {
        return instance.get().scheduleByID(getSandboxScheduleID()); 
    }    
    
    protected Story createStory(String name, Project project, Iteration iteration)
    {
        Story story = instance.create().story(name, project);
        story.setIteration(iteration);
        story.save();
        return story;
    }

    protected Defect createDefect(String name, Project project, Iteration iteration)
    {
        Defect defect = instance.create().defect(name, project);
        defect.setIteration(iteration);
        defect.save();
        return defect;
    }
    
    protected static <T> T First(Collection<T> list)
    {
    	Iterator<T> iter = list.iterator();
        if (iter.hasNext())
            return iter.next();
        return null;
    }
}
