package com.versionone.om.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.versionone.om.Epic;
import com.versionone.om.Member;
import com.versionone.om.Project;
import com.versionone.om.Story;
import com.versionone.om.filters.EpicFilter;

public class EpicFilterTester extends BaseSDKTester {
    private static final String HIGH = "High";
    private static final String MEDIUM = "Medium";
    private static final String DEFECT = "Defect";
    private static final String FIND_ME = "Find Me";
    private static final String SALES = "Sales";
    private Project sandboxProject;
    private Member andre;
    private Member danny;
	private Epic epic2;

    private EpicFilter getFilter() {
        EpicFilter filter = new EpicFilter();
        filter.project.add(sandboxProject);
        return filter;
    }

    @Before
    public void createAssets() {
        if (sandboxProject == null) {
            sandboxProject = getSandboxProject();

            andre = getInstance().get().memberByID("Member:1000");
            danny = getInstance().get().memberByID("Member:1005");

            Epic epic1 = sandboxProject.createEpic("Epic 1");
            epic2 = sandboxProject.createEpic("Epic 2");
            
		    Epic childEpic = epic2.generateChildEpic();
            childEpic.setName("Son of an Epic");
            childEpic.save();            
            
			epic1.setCustomer(andre);
            epic1.getSource().setCurrentValue("Customer");
            epic1.getRisk().setCurrentValue(MEDIUM);
            epic1.getType().setCurrentValue(DEFECT);
            epic1.save();

            epic2.getPriority().setCurrentValue(HIGH);
            epic2.getSource().setCurrentValue(SALES);
            epic2.setReference(FIND_ME);
            epic2.getRisk().setCurrentValue(HIGH);
            epic2.save();

            Story story1 = epic1.generateChildStory();
            story1.setReference(FIND_ME);
            story1.setCustomer(andre);
            story1.save();
        }
    }

    @Test
    public void testCustomer() {
        EpicFilter filter = getFilter();
        filter.customer.add(andre);
        Assert.assertEquals(1, getInstance().get().epics(filter).size());
    }

    @Test
    public void testSource() {
        EpicFilter filter = getFilter();
        filter.source.add(SALES);
        Assert.assertEquals(1, getInstance().get().epics(filter).size());
    }

    @Test
    public void testReference() {
        EpicFilter filter = getFilter();
        filter.reference.add(FIND_ME);
        Assert.assertEquals(1, getInstance().get().epics(filter).size());
    }

    @Test
    public void testType() {
        EpicFilter filter = getFilter();
        filter.type.add(DEFECT);
        Assert.assertEquals(1, getInstance().get().epics(filter).size());
    }

    @Test
    public void testRisk() {
        EpicFilter filter = getFilter();
        filter.risk.add(MEDIUM);
        Assert.assertEquals(1, getInstance().get().epics(filter).size());
    }

    @Test
    public void testPriority() {
        EpicFilter filter = getFilter();
        filter.priority.add(HIGH);
        Assert.assertEquals(1, getInstance().get().epics(filter).size());
    }

    @Test public void GetChildEpicsWithNullFilter() 
    {
        Epic epic = getInstance().get().epicByID(epic2.getID());
        Assert.assertEquals(1, epic.getChildEpics(null).size());
    }
    
    
	@Test
	public void testNoStoryAmongEpics()
	{
		Story decoy = getSandboxProject().createStory("Decoy");

		resetInstance();

		ListAssert.notcontains(decoy.getName(), getInstance().get().epics(null), new EntityToNameTransformer<Epic>());
	}
   
}
