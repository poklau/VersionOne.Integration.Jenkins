package com.versionone.om.tests;

import com.versionone.DB.DateTime;
import com.versionone.om.AssetID;
import com.versionone.om.Defect;
import com.versionone.om.Effort;
import com.versionone.om.Iteration;
import com.versionone.om.Member;
import com.versionone.om.Project;
import com.versionone.om.Team;

import org.junit.Assert;
import org.junit.Test;

/**
 * Effort tester.
 * <p>Not exist in .NET
 */
public class EffortTester extends BaseSDKTester {

    @Override
    protected Project createSandboxProject(Project rootProject) {
        return getInstance().create().project(getSandboxName(), rootProject, DateTime.now(), getSandboxSchedule());
    }

    @Test
    public void testCreateAndDeleteEffort() {
        final double effortValue = 23.1;
        final String defectName = "Defect effort name";
        final DateTime date = DateTime.now();

        final Member member = getInstance().get().memberByID("Member:1000");
        final Team team = getSandboxTeam();
        final Project project = getSandboxProject();
        final Defect defect = project.createDefect(defectName);
        final Iteration iteration = project.createIteration();
        final Effort effort = defect.createEffort(effortValue);
        effort.setDate(date);
        effort.setIteration(iteration);
        effort.setMember(member);
        effort.setTeam(team);
        effort.save();
        resetInstance();

        // verify
        final Effort actuialEffort = new Effort(effort.getID(), getInstance());
        Assert.assertEquals(member, actuialEffort.getMember());
        Assert.assertEquals(iteration, actuialEffort.getIteration());
        Assert.assertEquals(effortValue, actuialEffort.getValue(), ESTIMATES_PRECISION);
        Assert.assertEquals(team, actuialEffort.getTeam());
        Assert.assertEquals(date.getDate(), actuialEffort.getDate());

        // remove all created items
        team.delete();
        iteration.delete();
        defect.delete();
        project.delete();
    }
    
    @Test
    public void testGetById()
    {
        Effort effort = getInstance().get().effortByID(AssetID.fromToken("Actual:1448"));
        Assert.assertNotNull(effort);
        Assert.assertEquals(4.0, effort.getValue(), 0);
        Assert.assertEquals("Boris Tester", effort.getMember().getName());    	
    }    
}
