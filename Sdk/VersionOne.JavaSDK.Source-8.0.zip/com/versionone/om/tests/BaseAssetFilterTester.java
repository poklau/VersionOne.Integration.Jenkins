/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import com.versionone.DB;
import static com.versionone.apiclient.FilterTerm.Operator.GreaterThan;
import static com.versionone.apiclient.FilterTerm.Operator.GreaterThanOrEqual;
import static com.versionone.apiclient.FilterTerm.Operator.LessThan;
import static com.versionone.apiclient.FilterTerm.Operator.LessThanOrEqual;
import com.versionone.om.BaseAsset;
import com.versionone.om.Project;
import com.versionone.om.Story;
import com.versionone.om.Task;
import com.versionone.om.filters.BaseAssetFilter;

import org.junit.Ignore;
import org.junit.Test;

import java.util.Collection;

public class BaseAssetFilterTester extends BaseSDKTester {

    @Test
    public void testFindUnknownEntityType() {
        BaseAssetFilter filter = new BaseAssetFilter();

        filter.find.setSearchString(newGuid());
        Collection<BaseAsset> assets = getInstance().get().baseAssets(filter);
        ListAssert.areEqual(new BaseAsset[]{}, assets);
    }

    @Test
    public void testChangeDate() throws InterruptedException {
        final Project project = getSandboxProject();
        final Story story = project.createStory("Story1");
        Thread.sleep(1000);
        final Task task1 = story.createTask("Task1.1");
        Thread.sleep(1000);
        final Task task2 = story.createTask("Task1.2");
        final DB.DateTime task1Date = task1.getCreateDate().convertLocalToUtc();
        resetInstance();

        BaseAssetFilter filter = new BaseAssetFilter();
        filter.changeDateUtc.addTerm(GreaterThan, task1Date);
        Collection<BaseAsset> baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.notcontains(project, baseAssets);
        ListAssert.notcontains(story, baseAssets);
        ListAssert.notcontains(task1, baseAssets);
        ListAssert.contains(task2, baseAssets);

        filter.changeDateUtc.clear();
        filter.changeDateUtc.addTerm(GreaterThanOrEqual, task1Date);
        baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.notcontains(project, baseAssets);
        ListAssert.notcontains(story, baseAssets);
        ListAssert.contains(task1, baseAssets);
        ListAssert.contains(task2, baseAssets);

        filter.changeDateUtc.clear();
        filter.changeDateUtc.addTerm(LessThan, task1Date);
        baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.contains(project, baseAssets);
        ListAssert.contains(story, baseAssets);
        ListAssert.notcontains(task1, baseAssets);
        ListAssert.notcontains(task2, baseAssets);

        filter.changeDateUtc.clear();
        filter.changeDateUtc.addTerm(LessThanOrEqual, task1Date);
        baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.contains(project, baseAssets);
        ListAssert.contains(story, baseAssets);
        ListAssert.contains(task1, baseAssets);
        ListAssert.notcontains(task2, baseAssets);

        story.delete();
        project.delete();
    }

    @Test
    public void testCreateDate() throws InterruptedException {
        final Project project = getSandboxProject();
        final Story story = project.createStory("Story1");
        Thread.sleep(1000);
        final Task task1 = story.createTask("Task1.1");
        Thread.sleep(1000);
        final Task task2 = story.createTask("Task1.2");
        final DB.DateTime task1Date = task1.getCreateDate().convertLocalToUtc();
        resetInstance();

        BaseAssetFilter filter = new BaseAssetFilter();
        filter.createDateUtc.addTerm(GreaterThan, task1Date);
        Collection<BaseAsset> baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.notcontains(project, baseAssets);
        ListAssert.notcontains(story, baseAssets);
        ListAssert.notcontains(task1, baseAssets);
        ListAssert.contains(task2, baseAssets);

        filter.createDateUtc.clear();
        filter.createDateUtc.addTerm(GreaterThanOrEqual, task1Date);
        baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.notcontains(project, baseAssets);
        ListAssert.notcontains(story, baseAssets);
        ListAssert.contains(task1, baseAssets);
        ListAssert.contains(task2, baseAssets);

        filter.createDateUtc.clear();
        filter.createDateUtc.addTerm(LessThan, task1Date);
        baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.contains(project, baseAssets);
        ListAssert.contains(story, baseAssets);
        ListAssert.notcontains(task1, baseAssets);
        ListAssert.notcontains(task2, baseAssets);

        filter.createDateUtc.clear();
        filter.createDateUtc.addTerm(LessThanOrEqual, task1Date);
        baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.contains(project, baseAssets);
        ListAssert.contains(story, baseAssets);
        ListAssert.contains(task1, baseAssets);
        ListAssert.notcontains(task2, baseAssets);

        story.delete();
        project.delete();
    }

    @Test
    public void testFilterByName() {
        final String name = "English story";

        final Project project = getSandboxProject();
        final Story story = project.createStory(name);
        final Story story2 = project.createStory(name + '2');
        resetInstance();

        BaseAssetFilter filter = new BaseAssetFilter();
        filter.name.add(name);
        Collection<BaseAsset> assets = getInstance().get().baseAssets(filter);
        ListAssert.notcontains(project, assets);
        ListAssert.contains(story, assets);
        ListAssert.notcontains(story2, assets);
    }

    @Test
    @Ignore
    public void testFilterByInternationalName() {
        final String name = "\u0420\u0443\u0441 - ������� �������";

        final Project project = getSandboxProject();
        final Story story = project.createStory(name);
        resetInstance();

        BaseAssetFilter filter = new BaseAssetFilter();
        filter.name.add(name);
        Collection<BaseAsset> baseAssets = getInstance().get().baseAssets(filter);
        ListAssert.notcontains(project, baseAssets);
        ListAssert.contains(story, baseAssets);
    }
}
